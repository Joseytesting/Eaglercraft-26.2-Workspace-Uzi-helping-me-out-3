package fi.dy.masa.malilib.util.data.tag;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Optional;

import fi.dy.masa.malilib.util.data.Constants;
import fi.dy.masa.malilib.util.data.tag.util.SizeTracker;
import fi.dy.masa.malilib.util.data.tag.util.SizeTrackerException;

public class IntData extends BaseData implements NumberData
{
    public static final String TAG_NAME = "TAG_Int";

    public final int value;

    public IntData(int value)
    {
        super(Constants.NBT.TAG_INT, TAG_NAME);

        this.value = value;
    }

    public int getInt()
    {
        return this.value;
    }

    @Override
    public IntData copy()
    {
        return this;
    }

    @Override
    public String toString()
    {
        return this.value + "";
    }

    @Override
    public boolean isEmpty()
    {
        return false;
    }

    @Override
    public int sizeInBytes()
    {
        return Integer.BYTES;
    }

    @Override
    public Optional<Number> asNumber()
    {
        return Optional.of(this.value);
    }

    @Override
    public void write(DataOutput output) throws IOException, SizeTrackerException
    {
        output.writeInt(this.value);
    }

    public static IntData read(DataInput input, int depth, SizeTracker sizeTracker)
            throws IOException, SizeTrackerException
    {
        sizeTracker.increment(Integer.BYTES);
        return new IntData(input.readInt());
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) { return true; }
        if (o == null || this.getClass() != o.getClass()) { return false; }

        IntData other = (IntData) o;

        return this.value == other.value;
    }

    @Override
    public int hashCode()
    {
        return this.value;
    }
}
