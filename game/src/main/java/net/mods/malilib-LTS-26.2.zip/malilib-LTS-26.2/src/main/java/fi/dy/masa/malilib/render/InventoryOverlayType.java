package fi.dy.masa.malilib.render;

/**
 * Replaces the old / ugly method.
 */
public enum InventoryOverlayType
{
	BREWING_STAND,
	CRAFTER,
	DISPENSER,
	FURNACE,
	HOPPER,
	HORSE,
	LLAMA,
	NAUTILUS,
	SULFUR_CUBE,
	WOLF,
	HAPPY_GHAST,
	COPPER_GOLEM,
	FIXED_27,
	FIXED_54,
	VILLAGER,
	PLAYER,
	ENDER_CHEST,
	BOOKSHELF,
	WALL_SHELF,
	SINGLE_ITEM,
	BUNDLE,
	ARMOR_STAND,
	LIVING_ENTITY,
	GENERIC
}
